ALTER TABLE book
ADD COLUMN publisher varchar(255);