package com.polarbookshop.orderservice.order.domain;

public enum OrderStatus {
	ACCEPTED,
	REJECTED,
	DISPATCHED
}
